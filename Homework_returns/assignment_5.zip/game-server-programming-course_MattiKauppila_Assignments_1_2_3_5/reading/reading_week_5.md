# Reading list week 5

- Aggregation pipeline: https://docs.mongodb.com/manual/core/aggregation-pipeline/
- Indexes: https://docs.mongodb.com/manual/indexes/
- Replication: https://docs.mongodb.com/manual/replication/
- Sharding: https://docs.mongodb.com/manual/sharding/