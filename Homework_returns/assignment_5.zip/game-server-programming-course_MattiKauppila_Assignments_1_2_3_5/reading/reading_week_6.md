# Reading list week 6

- OWASP Top 10 Application security risks: https://www.owasp.org/index.php/Top_10-2017_Top_10
- Configuration: https://docs.microsoft.com/en-us/aspnet/core/fundamentals/configuration/?view=aspnetcore-2.1&tabs=basicconfiguration
- Middlewares: https://docs.microsoft.com/en-us/aspnet/core/fundamentals/middleware/?view=aspnetcore-2.1&tabs=aspnetcore2x
