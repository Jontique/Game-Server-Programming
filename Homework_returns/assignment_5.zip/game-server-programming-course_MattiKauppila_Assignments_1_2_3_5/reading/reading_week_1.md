# Reading list week 1

- Interfaces: https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/interfaces/
- Exception handling: https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/exceptions/exception-handling
- Creating and throwing exceptions: https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/exceptions/creating-and-throwing-exceptions
- Asynchronous programming: https://docs.microsoft.com/en-gb/dotnet/csharp/async
- Generics: https://docs.microsoft.com/en-gb/dotnet/csharp/programming-guide/generics/
- Delegates: https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/delegates/
- Lambda expressions: https://docs.microsoft.com/en-gb/dotnet/csharp/lambda-expressions