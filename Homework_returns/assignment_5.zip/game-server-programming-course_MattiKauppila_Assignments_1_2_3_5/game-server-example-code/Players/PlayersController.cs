using System;
using Microsoft.AspNetCore.Mvc;
using game_server.Validation;
using game_server.Repositories;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace game_server.Players
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayersController : ControllerBase
    {
        private readonly ILogger<PlayersController> _logger;
        
        private IRepository _repository;
     
        public PlayersController(ILogger<PlayersController> logger, IRepository repository)
        {
            _logger = logger;
            _repository =  repository;
        }

        [HttpGet]
        [Route("")]
        public async Task<Player[]> GetAll(int? minscore, string name, int? tag, int? itemcount, int? increment)
        {
            if(minscore != null) return await MinScore(minscore.Value);
            if(tag != null) return await _repository.GetUsersWithTag(tag.Value);
            if(itemcount != null) return await _repository.GetPlayersWithItemCount(itemcount.Value);
            //if(name != null && increment != null)
            //{
            //    await _repository.IncrementScore(name, increment);
            //}
            if(name != null) 
            {
                Player p = await _repository.GetPlayerWithName(name);
                List<Player> l = new List<Player>();
                l.Add(p);
                return l.ToArray();
            }
            return await _repository.GetAllPlayers();
        }

        public async Task<Player[]> MinScore(int minscore)
        {
            Console.WriteLine("Minscore requested");
            return await _repository.GetMinscore(minscore);
        }

        [HttpGet]
        [Route("{playerId}")]
        public async Task<Player> Get(string playerId)
        {
            return await _repository.GetPlayer(new Guid(playerId));
            //throw new NotImplementedException();
        }

        [HttpPost]
        [Route("")]
        [ValidateModel]
        public async Task<Player> Create(NewPlayer newPlayer)
        {
            var player = new Player();
            player.Id = Guid.NewGuid();
            player.Name = newPlayer.Name;
            return await _repository.CreatePlayer(player);
        }

        [HttpDelete]
        [Route("{playerId}")]
        public Task<Player> Ban(Guid playerId)
        {
            throw new NotImplementedException();
        }
    }
}