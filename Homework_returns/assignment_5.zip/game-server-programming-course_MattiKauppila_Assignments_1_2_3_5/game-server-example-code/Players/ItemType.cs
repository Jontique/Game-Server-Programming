namespace game_server.Players
{
    public enum ItemType
    {
        Weapon,
        Relic,
        HealthKit,
    }
}