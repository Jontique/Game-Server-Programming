﻿using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
//using System.Net.Http.HttpClient;
//https://github.com/vsillan/game-server-programming-course/blob/master/assignments/assignment_1.md FUTURICE

namespace _03092018_assignments
{
	public class Globals
	{
		public int bikeCount = 0;

		public float NameCompare(string a, string b)
		{
			string la = a.ToLower(), lb = b.ToLower();
			float l = 0, match = 0;
			if(b.Length > a.Length) l = a.Length;
			else l = b.Length;
			if(l < 0.0001 && l > -0.0001) return 0;

			for(int i = 0; i < (int)l; ++i)
			{
				if(la[i] == lb[i]) match += (-l-i) * (-l-i);
			}
			float percentage = match/l;
			//Console.WriteLine(la + " "+ lb + " " + "Length " + l + " Match " + match + " percentage " + percentage);
			return percentage;
		}

	}


	public class NotFoundException : Exception
	{
		public NotFoundException()
		{
		}

		public NotFoundException(string message) : base(message)
		{
			Console.WriteLine(message);
		}

		public NotFoundException(string message, Exception inner) : base(message, inner)
		{
		}
	}


	public class BikeRentalStation
	{

		public int id;
		public string name;
		public float x, y;
		public int bikesAvailable;
		public int spacesAvailable;
	}

	public class BikeRentalStationList
	{
		public BikeRentalStation[] stations;
	}

	public interface ICityBikeDataFetcher 
	{
    	Task<int> GetBikeCountInStation(string stationName);
	}

	class OfflineCityBikeDataFetcher : ICityBikeDataFetcher
	{

		Globals tools;
		bool loaded = false;
		BikeRentalStationList _bikeRentalStationList;

		public void SetBikeCount(int c)
		{
			return;
		}

		
		bool LoadMockData()
		{
			 string[] lines = System.IO.File.ReadAllLines(@"bikedata.txt");
			_bikeRentalStationList = new BikeRentalStationList();
			_bikeRentalStationList.stations = new BikeRentalStation[lines.Length];
			for(int i = 0; i < lines.Length; ++i)
			{
				string[] words = lines[i].Split(":");
				_bikeRentalStationList.stations[i].name = words[0];
				if(words.Length>1)
						_bikeRentalStationList.stations[i].bikesAvailable = Int32.Parse(words[1]);
				else
						_bikeRentalStationList.stations[i].bikesAvailable = 0;
			}
			loaded = true;
			return true;
		}

		bool ValidateString(string station)		// I know that this could have been done in a much more elegant way
		{										// just did not feel like it
			if(station.Contains("0")) return false;
			else if(station.Contains("1")) return false;
			else if(station.Contains("2")) return false;
			else if(station.Contains("3")) return false;
			else if(station.Contains("4")) return false;
			else if(station.Contains("5")) return false;
			else if(station.Contains("6")) return false;
			else if(station.Contains("7")) return false;
			else if(station.Contains("8")) return false;
			else if(station.Contains("9")) return false;
			return true;
		}

		int FindStation(string station)
		{
			if(loaded == false) LoadMockData();
			int best_hit_index = 0;
			for(int i = 0; i < _bikeRentalStationList.stations.Length; ++i)
			{
				if(_bikeRentalStationList.stations[i] != null)
				{
					float hit = 0;
					float best_hit = 0;
							
					hit = tools.NameCompare(station, _bikeRentalStationList.stations[i].name);
					if(hit > best_hit)
					{
						best_hit = hit;
						Console.WriteLine(hit);
						best_hit_index = i;
					}
				}			
			}
			return best_hit_index;
		}

		public async Task<int> GetBikeCountInStation(string station)
		{
			return 0;
		}
	}


	class RealTimeCityBikeDataFetcher : ICityBikeDataFetcher
	{
		public BikeRentalStationList _bikeRentalStationList = new BikeRentalStationList();
		public void SetBikeCount(int c)
		{
				Console.WriteLine("Bikes on station " + c);
		}

		bool ValidateString(string station)
		{
			if(station.Contains("0")) return false;
			else if(station.Contains("1")) return false;
			else if(station.Contains("2")) return false;
			else if(station.Contains("3")) return false;
			else if(station.Contains("4")) return false;
			else if(station.Contains("5")) return false;
			else if(station.Contains("6")) return false;
			else if(station.Contains("7")) return false;
			else if(station.Contains("8")) return false;
			else if(station.Contains("9")) return false;
			return true;
		}

		public async Task<int> GetBikeCountInStation(string station)
		{
			Globals tools = new Globals();
			var clientti = new System.Net.Http.HttpClient();
			Uri url = new Uri("http://api.digitransit.fi/routing/v1/routers/hsl/bike_rental");
   			string checkResult;
   			int best_hit_index = 0;
   			try
	        {
	            var result = await clientti.GetByteArrayAsync(url);
	            string Lstring = System.Text.Encoding.UTF8.GetString(result);
	            _bikeRentalStationList = Newtonsoft.Json.JsonConvert.DeserializeObject<BikeRentalStationList>(Lstring);
	            checkResult = Lstring;
	            clientti.Dispose();	            
	        }
	        catch (Exception ex)
	        {
	            checkResult = "Error " + ex.ToString();
	            //checkResult = "";
	            clientti.Dispose();
	        }

	        //Console.WriteLine(checkResult);
			try
			{
				if(!ValidateString(station)) throw new System.ArgumentException("There cannot be numbers in the station name");
				//if(!FindStation(station)) throw new NotFoundException("Station not found.");
				
			}
			catch(ArgumentException e)
			{
				Console.WriteLine(e.Message);
			}

			
			float best_hit = 0;
							

			for(int i = 0; i < _bikeRentalStationList.stations.Length; ++i)
			{
				if(_bikeRentalStationList.stations[i] != null)
				{
					float hit = 0;
					hit = tools.NameCompare(station, _bikeRentalStationList.stations[i].name);
					if(hit > best_hit)
					{
						best_hit = hit;
						best_hit_index = i;
					}
				}			
			}

				Console.WriteLine("Bike Stop " + _bikeRentalStationList.stations[best_hit_index].name + ", bikes available: " + _bikeRentalStationList.stations[best_hit_index].bikesAvailable);

				return 0;
		}
	}

    class Program
    {
    	bool stationsLoaded = false;
    	bool online = true;
    	//bool online = false;
		//List<string> stations = new List<string>();
		
		RealTimeCityBikeDataFetcher onlineFetcher = new RealTimeCityBikeDataFetcher();
		OfflineCityBikeDataFetcher offlineFetcher = new OfflineCityBikeDataFetcher();
        static void Main(string[] args)
        {

        	Program p = new Program();
        	if(args.Length < 1)
        			return;
        	if(online == true) p.onlineFetcher.GetBikeCountInStation(args[0]).Wait();
            else p.offlineFetcher.GetBikeCountInStation(args[0]).Wait();
            Console.WriteLine(args[0]);
        }

    }
}
